import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;

import com.sun.org.apache.xpath.internal.axes.ReverseAxesWalker;


public class FASE4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	String [] ciudades_init = {"Barcelona", "Madrid", "Valencia", "Malaga", "Cadis", "Santander", "Olten"};	
	
	ArrayList<char[]> CiudadArray = new ArrayList<char[]>();
	for(int i = 0;i<ciudades_init.length;i++)
	{
		CiudadArray.add(new char[ciudades_init[i].length()]);
		char [] temp = new char[ciudades_init[i].length()];
		
		for (int j = 0;j<ciudades_init[i].length();j++)
		{
			temp[j]=ciudades_init[i].charAt(j);
		}
		
		CiudadArray.set(i, temp);
		
		System.out.print(ciudades_init[i] + " - ");
		for (int j = CiudadArray.get(i).length-1; j >= 0 ; j--){
		    System.out.print(CiudadArray.get(i)[j]);			
		}
		System.out.print("\n");	
	}
}
}	